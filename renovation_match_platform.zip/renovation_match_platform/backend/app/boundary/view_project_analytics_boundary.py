from flask import Blueprint, render_template

from app.controller.view_project_analytics_controller import ViewProjectAnalyticsController
from app.services.auth import current_user_id, roles_required

bp = Blueprint("view_project_analytics", __name__)


@bp.get("/analytics")
@roles_required("INTERIOR_DESIGNER")
def analytics():
    controller = ViewProjectAnalyticsController()
    success, result = controller.view_project_analytics(current_user_id())
    return render_template("analytics.html", rows=result if success else [])
