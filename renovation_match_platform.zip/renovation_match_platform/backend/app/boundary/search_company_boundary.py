from flask import Blueprint, flash, render_template, request

from app.controller.search_company_controller import SearchCompanyController
from app.services.auth import current_user, roles_required

bp = Blueprint("search_company", __name__)


@bp.get("/companies/search")
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def company_search():
    q = request.args.get("q", "").strip()
    controller = SearchCompanyController()
    success, result = controller.search_companies(current_user(), q)
    if not success:
        flash(result, "danger")
    return render_template("companies.html", rows=result if success else [], q=q)
