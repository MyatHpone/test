from flask import Blueprint, flash, redirect, url_for

from app.controller.delete_project_controller import DeleteProjectController
from app.services.auth import abort_on_access_error, current_user, roles_required

bp = Blueprint("delete_project", __name__)


@bp.post("/projects/<int:project_id>/delete")
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def project_delete(project_id: int):
    controller = DeleteProjectController()
    success, result = controller.delete_project(current_user(), project_id)
    abort_on_access_error(result)
    flash(result, "success" if success else "danger")
    return redirect(url_for("view_project.projects"))
