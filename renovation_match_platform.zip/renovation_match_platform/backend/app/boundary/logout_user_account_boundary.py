from flask import Blueprint, flash, redirect, session, url_for

from app.controller.logout_user_account_controller import LogoutUserAccountController
from app.services.auth import current_user_id, login_required

bp = Blueprint("logout_user_account", __name__)


@bp.post("/logout")
@login_required
def logout():
    controller = LogoutUserAccountController()
    success, result = controller.logout_user(current_user_id())
    session.clear()
    flash(result if success else "You have logged out.", "success")
    return redirect(url_for("login_user_account.login"))
