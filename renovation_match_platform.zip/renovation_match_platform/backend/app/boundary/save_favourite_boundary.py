from flask import Blueprint, flash, redirect, request, url_for

from app.controller.save_favourite_controller import SaveFavouriteController
from app.services.auth import abort_on_access_error, current_user_id, roles_required

bp = Blueprint("save_favourite", __name__)


@bp.post("/projects/<int:project_id>/favourite")
@roles_required("CUSTOMER")
def favourite(project_id: int):
    controller = SaveFavouriteController()
    success, result = controller.save_favourite(current_user_id(), project_id)
    abort_on_access_error(result)
    flash(result, "success" if success else "danger")
    return redirect(request.referrer or url_for("view_project.projects"))
