from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.controller.create_category_controller import CreateCategoryController
from app.services.auth import current_user_id, roles_required

bp = Blueprint("create_category", __name__)


@bp.route("/categories/new", methods=["GET", "POST"])
@roles_required("PLATFORM_MANAGER")
def category_new():
    if request.method == "POST":
        controller = CreateCategoryController()
        success, result = controller.create_category(current_user_id(), request.form.to_dict())
        if success:
            flash(result, "success")
            return redirect(url_for("view_category.categories"))
        flash(result, "danger")
    return render_template("category_form.html", row=None)
