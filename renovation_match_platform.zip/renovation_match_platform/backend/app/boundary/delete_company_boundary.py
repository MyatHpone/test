from flask import Blueprint, flash, redirect, url_for

from app.controller.delete_company_controller import DeleteCompanyController
from app.services.auth import abort_on_access_error, current_user, roles_required

bp = Blueprint("delete_company", __name__)


@bp.post("/companies/<int:company_id>/delete")
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def company_delete(company_id: int):
    controller = DeleteCompanyController()
    success, result = controller.delete_company(current_user(), company_id)
    abort_on_access_error(result)
    flash(result, "success" if success else "danger")
    return redirect(url_for("view_company.companies"))
