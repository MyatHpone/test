from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.controller.update_category_controller import UpdateCategoryController
from app.controller.view_category_controller import ViewCategoryController
from app.services.auth import abort_on_access_error, current_user_id, roles_required

bp = Blueprint("update_category", __name__)


@bp.route("/categories/<int:category_id>/edit", methods=["GET", "POST"])
@roles_required("PLATFORM_MANAGER")
def category_edit(category_id: int):
    found, row = ViewCategoryController().view_category(category_id)
    if not found:
        abort_on_access_error(row)
    if request.method == "POST":
        controller = UpdateCategoryController()
        success, result = controller.update_category(current_user_id(), category_id, request.form.to_dict())
        if success:
            flash(result, "success")
            return redirect(url_for("view_category.categories"))
        abort_on_access_error(result)
        flash(result, "danger")
    return render_template("category_form.html", row=row)
