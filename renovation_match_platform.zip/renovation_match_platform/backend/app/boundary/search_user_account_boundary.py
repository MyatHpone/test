from flask import Blueprint, flash, render_template, request

from app.controller.search_user_account_controller import SearchUserAccountController
from app.services.auth import roles_required

bp = Blueprint("search_user_account", __name__)


@bp.get("/users/search")
@roles_required("USER_ADMIN")
def users_search():
    q = request.args.get("q", "").strip()
    controller = SearchUserAccountController()
    success, result = controller.search_user_accounts(q)
    if not success:
        flash(result, "danger")
    return render_template("users.html", rows=result if success else [], q=q)
