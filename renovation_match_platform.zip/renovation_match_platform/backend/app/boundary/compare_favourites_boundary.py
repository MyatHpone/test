from flask import Blueprint, render_template

from app.controller.compare_favourites_controller import CompareFavouritesController
from app.services.auth import current_user_id, roles_required

bp = Blueprint("compare_favourites", __name__)


@bp.get("/compare")
@roles_required("CUSTOMER")
def compare():
    controller = CompareFavouritesController()
    success, result = controller.compare_favourites(current_user_id())
    return render_template("compare.html", rows=result if success else [])
