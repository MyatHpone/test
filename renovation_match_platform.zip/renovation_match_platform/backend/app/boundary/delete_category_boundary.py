from flask import Blueprint, flash, redirect, url_for

from app.controller.delete_category_controller import DeleteCategoryController
from app.services.auth import abort_on_access_error, current_user_id, roles_required

bp = Blueprint("delete_category", __name__)


@bp.post("/categories/<int:category_id>/delete")
@roles_required("PLATFORM_MANAGER")
def category_delete(category_id: int):
    controller = DeleteCategoryController()
    success, result = controller.delete_category(current_user_id(), category_id)
    abort_on_access_error(result)
    flash(result, "success" if success else "danger")
    return redirect(url_for("view_category.categories"))
