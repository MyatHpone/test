from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from app.controller.login_user_account_controller import LoginUserAccountController

bp = Blueprint("login_user_account", __name__)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        controller = LoginUserAccountController()
        success, result = controller.login_user(request.form.get("username", ""),
                                                request.form.get("password", ""))
        if success:
            session.clear()
            session["user_id"] = result["id"]
            return redirect(url_for("view_dashboard.dashboard"))
        flash(result, "danger")
    return render_template("login.html")
