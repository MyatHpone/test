from flask import Blueprint, flash, redirect, request, url_for

from app.controller.update_user_profile_controller import UpdateUserProfileController
from app.services.auth import current_user_id, login_required

bp = Blueprint("update_user_profile", __name__)


@bp.post("/profile")
@login_required
def profile_update():
    controller = UpdateUserProfileController()
    success, result = controller.update_user_profile(current_user_id(), request.form.to_dict())
    flash(result, "success" if success else "danger")
    return redirect(url_for("view_user_profile.profile"))
