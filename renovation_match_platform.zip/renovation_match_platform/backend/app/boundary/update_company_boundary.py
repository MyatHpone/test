from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.controller.update_company_controller import UpdateCompanyController
from app.controller.view_company_controller import ViewCompanyController
from app.services.auth import abort_on_access_error, current_user, roles_required

bp = Blueprint("update_company", __name__)


@bp.route("/companies/<int:company_id>/edit", methods=["GET", "POST"])
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def company_edit(company_id: int):
    found, row = ViewCompanyController().view_company(current_user(), company_id)
    if not found:
        abort_on_access_error(row)
    if request.method == "POST":
        controller = UpdateCompanyController()
        success, result = controller.update_company(current_user(), company_id, request.form.to_dict())
        if success:
            flash(result, "success")
            return redirect(url_for("view_company.companies"))
        abort_on_access_error(result)
        flash(result, "danger")
    return render_template("company_form.html", row=row)
