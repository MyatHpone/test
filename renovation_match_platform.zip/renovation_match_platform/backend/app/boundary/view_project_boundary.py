from flask import Blueprint, render_template, request

from app.controller.view_project_controller import ViewProjectController

bp = Blueprint("view_project", __name__)


@bp.get("/projects")
def projects():
    status = request.args.get("status", "")
    controller = ViewProjectController()
    success, result = controller.view_projects(status)
    return render_template("projects.html", rows=result if success else [], q="", status=status)
