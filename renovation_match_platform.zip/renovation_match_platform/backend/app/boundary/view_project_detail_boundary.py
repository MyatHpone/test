from flask import Blueprint, render_template

from app.controller.view_project_detail_controller import ViewProjectDetailController
from app.services.auth import abort_on_access_error, current_user

bp = Blueprint("view_project_detail", __name__)


@bp.get("/projects/<int:project_id>")
def project_detail(project_id: int):
    controller = ViewProjectDetailController()
    success, result = controller.view_project(project_id, current_user())
    if not success:
        abort_on_access_error(result)
    return render_template("project_detail.html", row=result["project"], saved=result["saved"])
