from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.controller.create_user_account_controller import CreateUserAccountController
from app.services.auth import current_user_id, roles_required

bp = Blueprint("create_user_account", __name__)


@bp.route("/users/new", methods=["GET", "POST"])
@roles_required("USER_ADMIN")
def user_new():
    if request.method == "POST":
        controller = CreateUserAccountController()
        success, result = controller.create_user_account(current_user_id(), request.form.to_dict())
        if success:
            flash("User account created.", "success")
            return redirect(url_for("view_user_account.users_list"))
        flash(result, "danger")
    return render_template("user_form.html", row=None)
