from flask import Blueprint, render_template

from app.controller.view_favourites_controller import ViewFavouritesController
from app.services.auth import current_user_id, roles_required

bp = Blueprint("view_favourites", __name__)


@bp.get("/shortlist")
@roles_required("CUSTOMER")
def shortlist():
    controller = ViewFavouritesController()
    success, result = controller.view_favourites(current_user_id())
    return render_template("shortlist.html", rows=result if success else [], q="")
