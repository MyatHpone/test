from flask import Blueprint, flash, redirect, url_for

from app.controller.suspend_user_account_controller import SuspendUserAccountController
from app.services.auth import abort_on_access_error, current_user_id, roles_required

bp = Blueprint("suspend_user_account", __name__)


@bp.post("/users/<int:user_id>/suspend")
@roles_required("USER_ADMIN")
def user_suspend(user_id: int):
    controller = SuspendUserAccountController()
    success, result = controller.suspend_user_account(current_user_id(), user_id)
    if not success:
        abort_on_access_error(result)
    flash(result, "success" if success else "danger")
    return redirect(url_for("view_user_account.users_list"))
