from flask import Blueprint, flash, render_template, request

from app.controller.search_category_controller import SearchCategoryController
from app.services.auth import roles_required

bp = Blueprint("search_category", __name__)


@bp.get("/categories/search")
@roles_required("PLATFORM_MANAGER", "USER_ADMIN")
def category_search():
    q = request.args.get("q", "").strip()
    controller = SearchCategoryController()
    success, result = controller.search_categories(q)
    if not success:
        flash(result, "danger")
    return render_template("categories.html", rows=result if success else [], q=q)
