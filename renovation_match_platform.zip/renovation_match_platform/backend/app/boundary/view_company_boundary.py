from flask import Blueprint, render_template

from app.controller.view_company_controller import ViewCompanyController
from app.services.auth import current_user, roles_required

bp = Blueprint("view_company", __name__)


@bp.get("/companies")
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def companies():
    controller = ViewCompanyController()
    success, result = controller.view_all_companies(current_user())
    return render_template("companies.html", rows=result if success else [], q="")
