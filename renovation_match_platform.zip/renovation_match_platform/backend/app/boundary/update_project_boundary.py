from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.controller.update_project_controller import UpdateProjectController
from app.controller.view_project_controller import ViewProjectController
from app.services.auth import abort_on_access_error, current_user, roles_required

bp = Blueprint("update_project", __name__)


@bp.route("/projects/<int:project_id>/edit", methods=["GET", "POST"])
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def project_edit(project_id: int):
    controller = UpdateProjectController()
    found, row = controller.view_project_for_edit(current_user(), project_id)
    if not found:
        abort_on_access_error(row)
    if request.method == "POST":
        success, result = controller.update_project(current_user(), project_id, request.form.to_dict())
        if success:
            flash(result, "success")
            return redirect(url_for("view_project.projects"))
        abort_on_access_error(result)
        flash(result, "danger")
    _, (companies, categories) = ViewProjectController().view_form_options(current_user(), all_companies=True)
    return render_template("project_form.html", row=row, companies=companies, categories=categories)
