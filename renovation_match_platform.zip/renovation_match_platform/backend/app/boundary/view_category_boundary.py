from flask import Blueprint, render_template

from app.controller.view_category_controller import ViewCategoryController
from app.services.auth import roles_required

bp = Blueprint("view_category", __name__)


@bp.get("/categories")
@roles_required("PLATFORM_MANAGER", "USER_ADMIN")
def categories():
    controller = ViewCategoryController()
    success, result = controller.view_all_categories()
    return render_template("categories.html", rows=result if success else [], q="")
