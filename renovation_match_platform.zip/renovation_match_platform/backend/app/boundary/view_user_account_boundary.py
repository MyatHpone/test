from flask import Blueprint, render_template

from app.controller.view_user_account_controller import ViewUserAccountController
from app.services.auth import roles_required

bp = Blueprint("view_user_account", __name__)


@bp.get("/users")
@roles_required("USER_ADMIN")
def users_list():
    controller = ViewUserAccountController()
    success, result = controller.view_all_user_accounts()
    return render_template("users.html", rows=result if success else [], q="")
