from flask import Blueprint, flash, redirect, render_template, request, url_for

from app.controller.create_project_controller import CreateProjectController
from app.controller.view_project_controller import ViewProjectController
from app.services.auth import current_user, roles_required

bp = Blueprint("create_project", __name__)


@bp.route("/projects/new", methods=["GET", "POST"])
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def project_new():
    if request.method == "POST":
        controller = CreateProjectController()
        success, result = controller.create_project(current_user(), request.form.to_dict())
        if success:
            flash(result, "success")
            return redirect(url_for("view_project.projects"))
        flash(result, "danger")
    _, (companies, categories) = ViewProjectController().view_form_options(current_user())
    return render_template("project_form.html", row=None, companies=companies, categories=categories)
