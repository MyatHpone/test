from flask import Blueprint, abort, flash, redirect, render_template, request, url_for

from app.controller.update_user_account_controller import UpdateUserAccountController
from app.controller.view_user_account_controller import ViewUserAccountController
from app.services.auth import abort_on_access_error, current_user_id, roles_required

bp = Blueprint("update_user_account", __name__)


@bp.route("/users/<int:user_id>/edit", methods=["GET", "POST"])
@roles_required("USER_ADMIN")
def user_edit(user_id: int):
    found, row = ViewUserAccountController().view_user_account(user_id)
    if not found:
        abort(404)
    if request.method == "POST":
        controller = UpdateUserAccountController()
        success, result = controller.update_user_account(current_user_id(), user_id, request.form.to_dict())
        if success:
            flash(result, "success")
            return redirect(url_for("view_user_account.users_list"))
        abort_on_access_error(result)
        flash(result, "danger")
    return render_template("user_form.html", row=row)
