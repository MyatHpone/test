from flask import Blueprint, flash, redirect, session, url_for

from app.controller.suspend_user_profile_controller import SuspendUserProfileController
from app.services.auth import current_user_id, login_required

bp = Blueprint("suspend_user_profile", __name__)


@bp.post("/profile/suspend")
@login_required
def profile_suspend():
    controller = SuspendUserProfileController()
    success, result = controller.suspend_user_profile(current_user_id())
    if success:
        session.clear()
        flash(result, "info")
        return redirect(url_for("login_user_account.login"))
    flash(result, "danger")
    return redirect(url_for("view_user_profile.profile"))
