from flask import Blueprint, flash, render_template, request

from app.controller.search_user_profile_controller import SearchUserProfileController
from app.services.auth import roles_required

bp = Blueprint("search_user_profile", __name__)


@bp.get("/profiles")
@roles_required("USER_ADMIN", "PLATFORM_MANAGER", "INTERIOR_DESIGNER")
def profiles_search():
    q = request.args.get("q", "").strip()
    controller = SearchUserProfileController()
    success, result = controller.search_user_profiles(q)
    if not success:
        flash(result, "danger")
    return render_template("profiles.html", rows=result if success else [], q=q)
