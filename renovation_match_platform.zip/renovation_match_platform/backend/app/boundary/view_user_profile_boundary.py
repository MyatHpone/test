from flask import Blueprint, abort, render_template

from app.controller.view_user_profile_controller import ViewUserProfileController
from app.services.auth import current_user_id, login_required

bp = Blueprint("view_user_profile", __name__)


@bp.get("/profile")
@login_required
def profile():
    controller = ViewUserProfileController()
    success, result = controller.view_user_profile(current_user_id())
    if not success:
        abort(404)
    return render_template("profile.html", row=result)
