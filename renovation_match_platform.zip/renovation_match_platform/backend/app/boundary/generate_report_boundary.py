from datetime import date

from flask import Blueprint, flash, render_template, request

from app.controller.generate_report_controller import GenerateReportController
from app.services.auth import roles_required

bp = Blueprint("generate_report", __name__)


@bp.route("/reports", methods=["GET", "POST"])
@roles_required("PLATFORM_MANAGER")
def reports():
    result = None
    if request.method == "POST":
        controller = GenerateReportController()
        success, data = controller.generate_report(request.form.get("period", "daily"),
                                                   request.form.get("selected", date.today().isoformat()))
        if success:
            result = data
        else:
            flash(data, "danger")
    return render_template("reports.html", result=result, today=date.today().isoformat())
