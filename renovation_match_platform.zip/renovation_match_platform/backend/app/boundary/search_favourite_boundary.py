from flask import Blueprint, flash, render_template, request

from app.controller.search_favourite_controller import SearchFavouriteController
from app.services.auth import current_user_id, roles_required

bp = Blueprint("search_favourite", __name__)


@bp.get("/shortlist/search")
@roles_required("CUSTOMER")
def shortlist_search():
    q = request.args.get("q", "").strip()
    controller = SearchFavouriteController()
    success, result = controller.search_favourites(current_user_id(), q)
    if not success:
        flash(result, "danger")
    return render_template("shortlist.html", rows=result if success else [], q=q)
