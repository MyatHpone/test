from flask import Blueprint, redirect, render_template, url_for

from app.controller.view_dashboard_controller import ViewDashboardController
from app.services.auth import current_user, login_required

bp = Blueprint("view_dashboard", __name__)


@bp.get("/")
def index():
    target = "view_dashboard.dashboard" if current_user() else "login_user_account.login"
    return redirect(url_for(target))


@bp.get("/dashboard")
@login_required
def dashboard():
    controller = ViewDashboardController()
    success, result = controller.view_dashboard()
    if not success:
        return render_template("error.html", code=500, message=result), 500
    return render_template("dashboard.html", counts=result["counts"], projects=result["projects"])
