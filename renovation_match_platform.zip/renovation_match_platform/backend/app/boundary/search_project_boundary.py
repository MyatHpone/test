from flask import Blueprint, flash, render_template, request

from app.controller.search_project_controller import SearchProjectController

bp = Blueprint("search_project", __name__)


@bp.get("/projects/search")
def project_search():
    q, status = request.args.get("q", "").strip(), request.args.get("status", "")
    controller = SearchProjectController()
    success, result = controller.search_projects(q, status)
    if not success:
        flash(result, "danger")
    return render_template("projects.html", rows=result if success else [], q=q, status=status)
