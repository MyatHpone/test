from flask import Blueprint, flash, redirect, request, url_for

from app.controller.create_company_controller import CreateCompanyController
from app.services.auth import current_user_id, roles_required

bp = Blueprint("create_company", __name__)


@bp.post("/companies")
@roles_required("INTERIOR_DESIGNER", "USER_ADMIN")
def company_create():
    controller = CreateCompanyController()
    success, result = controller.create_company(current_user_id(), request.form.to_dict())
    flash(result, "success" if success else "danger")
    return redirect(url_for("view_company.companies"))
